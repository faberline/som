"""Lossless structural tokens with validated prompt bindings, without answers.

Both runtime decoders use a bounded scalar table built from public contracts
and the public prompt. The model emits every container, key, value and order.
No file, block, inverse or reference is reconstructed by a planner.
"""

import json
import re

from . import composed, flow
from .v1 import V1Error

VERSION = "som.flow.codec.v1"
LIMIT = 2048
STRUCTURE = ["<pad>", "<eos>", "<map>", "</map>", "<list>", "</list>", "<input>", "<plan>"]
TOKENS = STRUCTURE + [f"<v:{index}>" for index in range(1016)]
FIXED = """version files flow path blocks id name params refs $ref steps condition then else exports result input step field literal type args undo op inputs package resources parent child relation foreign_key on_delete operations scope action capabilities database auth storage workflow value_field group_field migration revision down_revision contract sha256 fields required unique default query filter_field date_field max_limit eq ne lt le gt ge is_null authorize transaction if delete_created restore_patch key body parent_id child_id data children csv create get list patch delete batch_create string integer float boolean date bytes str int bool parent_input child_input parent_patch child_patch children_input parent_row child_row parent_rows child_rows identity object batch json workflow sub role size sha256 id created_at updated_at resource typed_literal flow_name table path foreign_key revision down_revision parent_fk""".split()


def scalar_key(value):
    return composed.canonical(value)


def pool(prompt, normalized=False):
    """Use no corpus, label, expected plan or program text."""
    flow.validate(prompt)
    metadata = json.loads(flow.CATALOG.read_text())
    static = set(FIXED) | {flow.VERSION, flow.DSL_VERSION, flow.CONTRACT, "som.dsl.v2", "symbol"}
    static |= {"postgresql", "mongodb", "jwt", "firebase", "google_oauth", "none", "s3", "gcs", "json_export", "gzip_export", "csv", "decimal_summary", "statistics", "restrict"}
    static |= {"n"+str(index) for index in range(32)} | {"i"+str(index) for index in range(8)} | {"f"+str(index) for index in range(8)} | {"r"+str(index) for index in range(8)}
    static |= set(metadata["blocks"]) | set(metadata["slots"].values())
    for entry in metadata["blocks"].values():
        static.add(entry["provides"].split(":", 1)[1])
        static |= set(entry["bindings"])
        static |= {binding["$ref"] for binding in entry["bindings"].values()}
    result = [None, False, True, *sorted(static)]
    seen = {scalar_key(value) for value in result}
    def visit(value):
        if isinstance(value, dict):
            for key in sorted(value): visit(key); visit(value[key])
        elif isinstance(value, list):
            for item in value: visit(item)
        else:
            key = scalar_key(value)
            if key not in seen: seen.add(key); result.append(value)
    if not normalized: visit(prompt)
    visit(flow.semantic_view(prompt))
    if len(result) > 1016:
        raise V1Error("SCOPE_TOO_LARGE", "flow scalar binding table exceeds vocabulary")
    return result


def serialize(value, values):
    indices = {scalar_key(value): index for index, value in enumerate(values)}
    tokens = []
    def emit(value):
        if isinstance(value, dict):
            tokens.append("<map>")
            for key in sorted(value): emit(key); emit(value[key])
            tokens.append("</map>")
        elif isinstance(value, list):
            tokens.append("<list>")
            for item in value: emit(item)
            tokens.append("</list>")
        else:
            index = indices.get(scalar_key(value))
            if index is None: raise V1Error("INVALID_REF", "unknown scalar binding")
            tokens.append(f"<v:{index}>")
    emit(value)
    return tokens


def features(prompt):
    values = pool(prompt, normalized=True)
    outputs = pool(prompt)
    indices = {scalar_key(value): index for index, value in enumerate(outputs)}
    # A destination token is visible with its semantic role. Names and
    # constants remain private bindings, even if they equal vocabulary words.
    tokens = ["<input>", *serialize(flow.semantic_view(prompt), values), "<list>"]
    def binding(kind, slot, value):
        tokens.extend(["<list>", *serialize(kind, values), *serialize(slot, values), f"<v:{indices[scalar_key(value)]}>", "</list>"])
    binding("flow", "flow_name", prompt["flow"]["name"])
    for index, item in enumerate(prompt["flow"]["inputs"]): binding("input", "i"+str(index), item["name"])
    step_index=0
    def nodes(items):
        nonlocal step_index
        for node in items:
            binding("step", "n"+str(step_index), node["name"]); step_index+=1
            if node["op"]=="transaction": nodes(node["steps"])
            elif node["op"]=="if":
                nodes(node["then"]); nodes(node["else"])
                for name in sorted(node["exports"]): binding("step", "n"+str(step_index), name); step_index+=1
    nodes(prompt["flow"]["steps"])
    for role in ("parent", "child"):
        for index, definition in enumerate(prompt["resources"][role]["fields"]): binding(role,"f"+str(index),definition["name"])
    binding("relation", "parent_fk", prompt["relation"]["foreign_key"])
    def constants(value):
        if isinstance(value, dict):
            if set(value)=={"literal", "type"}: binding("literal",value["type"],value["literal"])
            else:
                for key in sorted(value): constants(value[key])
        elif isinstance(value,list):
            for item in value: constants(item)
    constants(prompt["flow"])
    for name,ref in sorted(prompt["flow"]["result"].items()):
        from copy import deepcopy
        q=deepcopy(prompt);q["flow"]["result"]={name:ref}
        projected=flow.semantic_view(q)["flow"]["result"]["r0"]
        tokens.extend(["<list>", *serialize("result",values), *serialize(projected,values), f"<v:{indices[scalar_key(name)]}>", "</list>"])
    tokens.extend(["</list>", "<plan>"])
    if len(tokens) > LIMIT: raise V1Error("SCOPE_TOO_LARGE", "flow input exceeds 2048 tokens")
    return "".join(tokens)


def encode(prompt, dsl):
    flow.validate_plan(prompt, dsl)
    tokens = [*serialize(dsl, pool(prompt)), "<eos>"]
    if len(tokens) > LIMIT: raise V1Error("SCOPE_TOO_LARGE", "flow output exceeds 2048 tokens")
    return "".join(tokens)


def decode(prompt, text):
    values = pool(prompt)
    tokens = re.findall(r"<[^<>\s]+>", text)
    if "".join(tokens) != text or not tokens or tokens[-1] != "<eos>":
        raise V1Error("INVALID_DSL", "malformed or incomplete flow token sequence")
    if len(tokens) > LIMIT: raise V1Error("SCOPE_TOO_LARGE", "flow output exceeds 2048 tokens")
    index = 0
    def read(depth=0):
        nonlocal index
        if depth > 32 or index >= len(tokens)-1: raise V1Error("INVALID_DSL", "truncated or deep flow sequence")
        token = tokens[index]; index += 1
        if token in {"<map>", "<list>"}:
            end = "</map>" if token == "<map>" else "</list>"
            result = {} if token == "<map>" else []
            while index < len(tokens)-1 and tokens[index] != end:
                value = read(depth+1)
                if token == "<map>":
                    if not isinstance(value, str) or value in result: raise V1Error("INVALID_DSL", "invalid or duplicate map key")
                    result[value] = read(depth+1)
                else: result.append(value)
            if index >= len(tokens)-1: raise V1Error("INVALID_DSL", "unclosed container")
            index += 1
            return result
        match = re.fullmatch(r"<v:(0|[1-9][0-9]*)>", token)
        if match is None or int(match[1]) >= len(values): raise V1Error("INVALID_DSL", "unknown structural token or binding")
        return values[int(match[1])]
    result = read()
    if index != len(tokens)-1: raise V1Error("INVALID_DSL", "extra tokens after plan")
    flow.validate_plan(prompt, result)
    return result
