//! Exact structural decoding. All scalar bindings come from checked input.
use crate::{SomError,flow};
use serde_json::{Value,json};
use std::collections::BTreeSet;

pub const VERSION:&str="som.flow.codec.v1";
pub const LIMIT:usize=2048;
const FIXED:&str="version files flow path blocks id name params refs $ref steps condition then else exports result input step field literal type args undo op inputs package resources parent child relation foreign_key on_delete operations scope action capabilities database auth storage workflow value_field group_field migration revision down_revision contract sha256 fields required unique default query filter_field date_field max_limit eq ne lt le gt ge is_null authorize transaction if delete_created restore_patch key body parent_id child_id data children csv create get list patch delete batch_create string integer float boolean date bytes str int bool parent_input child_input parent_patch child_patch children_input parent_row child_row parent_rows child_rows identity object batch json workflow sub role size sha256 id created_at updated_at resource typed_literal flow_name table path foreign_key revision down_revision parent_fk";
fn err(code:&'static str,detail:&str)->SomError {SomError::new(code,detail)}
pub fn pool(prompt:&Value,normalized:bool)->Result<Vec<Value>,SomError> {
    flow::validate(prompt)?;
    let mut fixed:BTreeSet<String>=FIXED.split_whitespace().map(str::to_owned).collect();
    fixed.extend([flow::VERSION,flow::DSL_VERSION,flow::CONTRACT,"som.dsl.v2","symbol","postgresql","mongodb","jwt","firebase","google_oauth","none","s3","gcs","json_export","gzip_export","csv","decimal_summary","statistics","restrict"].into_iter().map(str::to_owned));
    for (prefix,count) in [("n",32),("i",8),("f",8),("r",8)] {for i in 0..count {fixed.insert(format!("{prefix}{i}"));}}
    fixed.extend(flow::CATALOG["blocks"].as_object().unwrap().keys().cloned());
    fixed.extend(flow::CATALOG["slots"].as_object().unwrap().values().map(|v|v.as_str().unwrap().to_owned()));
    for entry in flow::CATALOG["blocks"].as_object().unwrap().values() {
        fixed.insert(entry["provides"].as_str().unwrap().split_once(':').unwrap().1.into());
        for (key,binding) in entry["bindings"].as_object().unwrap() {fixed.insert(key.clone());fixed.insert(binding["$ref"].as_str().unwrap().into());}
    }
    let mut result=vec![Value::Null,json!(false),json!(true)]; result.extend(fixed.into_iter().map(Value::String));
    let mut seen:BTreeSet<String>=result.iter().map(|v|serde_json::to_string(v).unwrap()).collect();
    fn visit(value:&Value,result:&mut Vec<Value>,seen:&mut BTreeSet<String>) {
        match value {
            Value::Object(map)=>for (key,value) in map {visit(&json!(key),result,seen);visit(value,result,seen);},
            Value::Array(list)=>for item in list {visit(item,result,seen);},
            _=>if seen.insert(serde_json::to_string(value).unwrap()) {result.push(value.clone());},
        }
    }
    if !normalized {visit(prompt,&mut result,&mut seen);}
    visit(&flow::semantic_view(prompt)?,&mut result,&mut seen);
    if result.len()>1016 {return Err(err("SCOPE_TOO_LARGE","scalar binding table exceeds vocabulary"));}
    Ok(result)
}
fn serialize(value:&Value,pool:&[Value],out:&mut Vec<String>)->Result<(),SomError> {
    match value {
        Value::Object(map)=>{
            out.push("<map>".into());
            for (key,value) in map {serialize(&json!(key),pool,out)?;serialize(value,pool,out)?;}
            out.push("</map>".into());
        }
        Value::Array(list)=>{
            out.push("<list>".into());for value in list {serialize(value,pool,out)?;}out.push("</list>".into());
        }
        _=>{
            let key=serde_json::to_string(value).unwrap();
            let index=pool.iter().position(|v|serde_json::to_string(v).unwrap()==key).ok_or_else(||err("INVALID_REF","unknown scalar binding"))?;
            out.push(format!("<v:{index}>"));
        }
    }
    Ok(())
}
pub fn features(prompt:&Value)->Result<String,SomError> {
    let values=pool(prompt,true)?;let outputs=pool(prompt,false)?;
    fn binding(kind:&str,slot:&str,value:&Value,values:&[Value],outputs:&[Value],out:&mut Vec<String>)->Result<(),SomError> {
        out.push("<list>".into());serialize(&json!(kind),values,out)?;serialize(&json!(slot),values,out)?;serialize(value,outputs,out)?;out.push("</list>".into());Ok(())
    }
    let mut out=vec!["<input>".into()];serialize(&flow::semantic_view(prompt)?,&values,&mut out)?;out.push("<list>".into());
    binding("flow","flow_name",&prompt["flow"]["name"],&values,&outputs,&mut out)?;
    for (i,input) in prompt["flow"]["inputs"].as_array().unwrap().iter().enumerate() {binding("input",&format!("i{i}"),&input["name"],&values,&outputs,&mut out)?;}
    fn nodes(items:&Value,index:&mut usize,values:&[Value],outputs:&[Value],out:&mut Vec<String>)->Result<(),SomError> {
        for node in items.as_array().unwrap() {
            binding("step",&format!("n{index}"),&node["name"],values,outputs,out)?;*index+=1;
            match node["op"].as_str().unwrap() {
                "transaction"=>nodes(&node["steps"],index,values,outputs,out)?,
                "if"=>{
                    nodes(&node["then"],index,values,outputs,out)?;nodes(&node["else"],index,values,outputs,out)?;
                    for name in node["exports"].as_object().unwrap().keys() {binding("step",&format!("n{index}"),&json!(name),values,outputs,out)?;*index+=1;}
                }
                _=>{}
            }
        }
        Ok(())
    }
    nodes(&prompt["flow"]["steps"],&mut 0,&values,&outputs,&mut out)?;
    for role in ["parent","child"] {for (i,field) in prompt["resources"][role]["fields"].as_array().unwrap().iter().enumerate() {binding(role,&format!("f{i}"),&field["name"],&values,&outputs,&mut out)?;}}
    binding("relation","parent_fk",&prompt["relation"]["foreign_key"],&values,&outputs,&mut out)?;
    fn constants(value:&Value,values:&[Value],outputs:&[Value],out:&mut Vec<String>)->Result<(),SomError> {
        match value {
            Value::Object(map)=>{
                if map.len()==2 && map.contains_key("literal") && map.contains_key("type") {binding("literal",map["type"].as_str().unwrap(),&map["literal"],values,outputs,out)?;}
                else {for value in map.values() {constants(value,values,outputs,out)?;}}
            }
            Value::Array(list)=>for item in list {constants(item,values,outputs,out)?;},
            _=>{}
        }
        Ok(())
    }
    constants(&prompt["flow"],&values,&outputs,&mut out)?;
    for (name,reference) in prompt["flow"]["result"].as_object().unwrap() {
        let mut copy=prompt.clone();copy["flow"]["result"]=json!({name:reference});
        out.push("<list>".into());serialize(&json!("result"),&values,&mut out)?;
        serialize(&flow::semantic_view(&copy)?["flow"]["result"]["r0"],&values,&mut out)?;
        serialize(&json!(name),&outputs,&mut out)?;out.push("</list>".into());
    }
    out.extend(["</list>".into(),"<plan>".into()]);
    if out.len()>LIMIT {return Err(err("SCOPE_TOO_LARGE","flow input exceeds 2048 tokens"));}Ok(out.concat())
}
pub fn encode(prompt:&Value,dsl:&Value)->Result<String,SomError> {
    flow::validate_plan(prompt,dsl)?;
    let mut out=vec![];serialize(dsl,&pool(prompt,false)?,&mut out)?;out.push("<eos>".into());
    if out.len()>LIMIT {return Err(err("SCOPE_TOO_LARGE","flow output exceeds 2048 tokens"));}Ok(out.concat())
}
pub fn decode(prompt:&Value,text:&str)->Result<Value,SomError> {
    let pool=pool(prompt,false)?;
    let regex=regex::Regex::new(r"<[^<>\s]+>").unwrap();
    let tokens:Vec<&str>=regex.find_iter(text).map(|m|m.as_str()).collect();
    if tokens.concat()!=text || tokens.last()!=Some(&"<eos>") {return Err(err("INVALID_DSL","malformed or incomplete flow token sequence"));}
    if tokens.len()>LIMIT {return Err(err("SCOPE_TOO_LARGE","flow output exceeds 2048 tokens"));}
    fn read(tokens:&[&str],pool:&[Value],index:&mut usize,depth:usize)->Result<Value,SomError> {
        if depth>32 || *index>=tokens.len()-1 {return Err(err("INVALID_DSL","truncated or deep flow sequence"));}
        let token=tokens[*index];*index+=1;
        if ["<map>","<list>"].contains(&token) {
            let end=if token=="<map>" {"</map>"} else {"</list>"};
            let mut list=vec![];let mut map=serde_json::Map::new();
            while *index<tokens.len()-1 && tokens[*index]!=end {
                let value=read(tokens,pool,index,depth+1)?;
                if token=="<map>" {
                    let key=value.as_str().ok_or_else(||err("INVALID_DSL","invalid map key"))?;
                    if map.contains_key(key) {return Err(err("INVALID_DSL","duplicate map key"));}
                    map.insert(key.into(),read(tokens,pool,index,depth+1)?);
                } else {list.push(value);}
            }
            if *index>=tokens.len()-1 {return Err(err("INVALID_DSL","unclosed container"));}*index+=1;
            return Ok(if token=="<map>" {Value::Object(map)} else {json!(list)});
        }
        let raw=token.strip_prefix("<v:").and_then(|s|s.strip_suffix('>')).filter(|n|!n.is_empty() && n.bytes().all(|b|b.is_ascii_digit()) && (n.len()==1 || !n.starts_with('0'))).ok_or_else(||err("INVALID_DSL","unknown structural token"))?;
        let n:usize=raw.parse().map_err(|_|err("INVALID_DSL","unknown scalar binding"))?;
        pool.get(n).cloned().ok_or_else(||err("INVALID_DSL","unknown scalar binding"))
    }
    let mut index=0;let dsl=read(&tokens,&pool,&mut index,0)?;
    if index!=tokens.len()-1 {return Err(err("INVALID_DSL","extra tokens after plan"));}
    flow::validate_plan(prompt,&dsl)?;Ok(dsl)
}
